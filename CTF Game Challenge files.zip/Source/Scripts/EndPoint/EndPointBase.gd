extends Area2D

var data: Dictionary

@onready var dnsLabel: Label = $VBoxContainer/DNS
@onready var ipLabel: Label = $VBoxContainer/IP

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		var playerWon: bool = check_value(body)
		body.handle_player_points(playerWon)

func _ready() -> void:
	print("I extist @", global_position)
	set_UI()

func set_UI() -> void:
	dnsLabel.text = data[Global.PlayerData.DNS_DESTINATION]
	ipLabel.text = data[Global.PlayerData.IP_ADDRESS]

func check_value(body : Player) -> bool:
	var result: bool = body.dnsLabel.text == self.dnsLabel.text
	return result
