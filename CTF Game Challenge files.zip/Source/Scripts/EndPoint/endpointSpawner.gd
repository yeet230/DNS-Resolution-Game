class_name Spawner extends Node2D

const END_POINT = preload("uid://dw4bakp2u1e4u")

var lastRealSpot: int

func spawn_endpoints(data: Dictionary) -> void:
	var spawnPointNode = get_tree().get_first_node_in_group("endPointSpawn")
	var realDns: String = data[Global.PlayerData.DNS_DESTINATION]
	var realSpot: int = randi_range(0, 3)
	var spacing: float = get_viewport_rect().size.x / 4.5 #The spacing between endpoints. The lower it is the higher the distance will be to other endpoints and vice versa. the higher it is the less spacing there is between each endpoint  
	
	while realSpot == lastRealSpot:
		realSpot = randi_range(0, 3)
	
	lastRealSpot = realSpot
	
	for i in range(4):
		var point = END_POINT.instantiate()
		
		# Centres all endpoints around the spawn node.
		point.position.x = (i - 1.5) * spacing
		
		if i != realSpot:
			var randomIp: String = Global.generate_ip_address()
			var fakeDns: String = Global.generate_fake_dns(realDns)
			
			point.data = {
				Global.PlayerData.DNS_DESTINATION: fakeDns,
				Global.PlayerData.IP_ADDRESS: randomIp
			}
		else:
			point.data = data
		
		spawnPointNode.add_child.call_deferred(point)


func reset() -> void:
	var endPointNodeParent = get_tree().get_first_node_in_group("endPointSpawn")
	
	for child in endPointNodeParent.get_children():
		child.queue_free()
