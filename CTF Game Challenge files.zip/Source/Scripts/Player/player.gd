class_name Player extends CharacterBody2D

@export var levelController: Node2D

var mouseOnCharecter: bool = false
var draggingDistance: float
var dir: Vector2
var dragging: bool
var newPosition: Vector2
var moveSpd: Vector2 = Vector2(3000, 3000)

@onready var ttlTimer: Timer = $Timer

@onready var colorRect: ColorRect = $ColorRect
@onready var dnsLabel: Label = $VBoxContainer/DNS
@onready var ipLabel: Label = $VBoxContainer/IP
@onready var ttlLabel: Label = $VBoxContainer/TTL


func _input(event):
	if event is InputEventMouseButton:
		if event.is_pressed() && mouseOnCharecter:
			draggingDistance = position.distance_to(get_viewport().get_mouse_position())
			dir = (get_viewport().get_mouse_position() - position).normalized()
			dragging = true
			newPosition = get_viewport().get_mouse_position() - draggingDistance * dir
		else:
			dragging = false
			
	elif event is InputEventMouseMotion:
		if dragging:
			newPosition = get_viewport().get_mouse_position() - draggingDistance * dir
	elif event.is_action_pressed("ui_accept"):
		player_reset()

func _physics_process(delta):
	
	if dragging:
		velocity = (newPosition - position) * (moveSpd * delta)
		move_and_slide()
	
	var timeLeft: float = ttlTimer.time_left
	ttlLabel.text = ("%2f" % timeLeft)

func update_player_data(data : Dictionary) -> void:
	print(data)
	dnsLabel.text = str(data[Global.PlayerData.DNS_DESTINATION])
	ipLabel.text = str(data[Global.PlayerData.IP_ADDRESS])
	var solveTime: int = (data[Global.PlayerData.TIME_TO_RESOLVE])
	
	ttlTimer.start(solveTime)

 
func _on_area_2d_mouse_entered() -> void:
	mouseOnCharecter = true
	#print("mouse enters")
	#colorRect.color = Color(0.0, 0.374, 0.0, 1.0)

func _on_area_2d_mouse_exited() -> void:
	mouseOnCharecter = false
	#print("mouse left")
	#colorRect.color = Color(0.374, 0.0, 0.0, 1.0)


func player_reset() -> void:
	global_position = Vector2(0, 193)
	dragging = false

##Won is the deterninig argument. if it is true the player will gain 100 points towards their score on the other hand if it is false the player will loose 50 points.
##The default value is false 
func handle_player_points(won : bool = false) -> void:
	if won:
		levelController.player_succeed()
	else:
		levelController.player_failed()

func _on_timer_timeout() -> void:
	handle_player_points(false)
