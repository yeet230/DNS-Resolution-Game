extends Control

@onready var scoreLabel: Label = $VBoxContainer/Score
@onready var ctfKey: Label = $VBoxContainer/CTFKey

func update_score() -> void:
	var playerScore: int = Global.score
	scoreLabel.text = str("Score: ", playerScore)
	
	if playerScore >= 750:
		ctfKey.text = "CTF_KEY{{0}}".format([Global.CTF_KEY])
