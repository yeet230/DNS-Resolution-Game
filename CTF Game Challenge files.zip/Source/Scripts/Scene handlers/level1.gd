extends Node2D

@export var gameNode: Node = get_parent()
@export var player: Player

@onready var spawner: Spawner = $Spawner


func _ready() -> void:
	var data = get_new_data()
	player.update_player_data(data)
	
	spawner.spawn_endpoints(data)
	

func player_failed() -> void:
	Global.score -= 50
	_refresh_level()
	

func player_succeed() -> void:
	Global.score += 100
	_refresh_level()

func _refresh_level() -> void:
	
	var data = get_new_data()
	player.update_player_data(data)
	player.player_reset()
	
	spawner.reset()
	spawner.spawn_endpoints(data)
	

func get_new_data() -> Dictionary:
	var data: Dictionary = Global.assign_player_data()
	return data
