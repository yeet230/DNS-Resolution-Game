extends Node

@onready var timer: Timer = $Timer
@onready var endHud: CanvasLayer = $EndHud
@onready var endScene: Control = $EndHud/Control
@onready var level_1: Node2D = $Level1

func _handle_game_end() -> void:
	endHud.show()
	endScene.update_score()
	level_1.process_mode = Node.PROCESS_MODE_DISABLED
	print(Global.score)
	


func _on_timer_timeout() -> void:
	_handle_game_end()

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("restart"):
		get_tree().reload_current_scene()
