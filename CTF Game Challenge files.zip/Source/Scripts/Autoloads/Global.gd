extends Node

enum PlayerData {
	DNS_DESTINATION,
	TIME_TO_RESOLVE,
	IP_ADDRESS,
}

const CTF_KEY = "DNS_H0ST_R34CH3D_SUCCS3FULLY"

var possibleValidDnsNames: Array[String] = [
	"Youtube.com",
	"Google.com",
	"Example.com",
	"Wikipedia.org",
	"KhanAcademy.org",
	"Netflix.com",
	"Reddit.com",
	"Amazon.com",
	"ChatGPT.com",
	"Temu.com",
	"Bing.com",
	"AustralianMade.com.au",
	"SuperCoolSchool.edu.au",
	
]

var score: int = 0



var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()


var substitutions : Dictionary = {
	"a": ["4", "@"],
	"b": ["8", "6"],
	"e": ["3"],
	"g": ["9", "q"],
	"i": ["1", "l", "!"],
	"l": ["1", "i"],
	"o": ["0"],
	"s": ["5", "$"],
	"t": ["7"],
	"z": ["2"],
	".": [","]
}


func generate_fake_dns(realDns: String, replaceChance: float = 0.25) -> String:
	var result : String = ""

	for character in realDns:
		var lowerChar : String = character.to_lower()
		
		if substitutions.has(lowerChar) and rng.randf() < replaceChance:
			var options: Array = substitutions[lowerChar]
			result += options[rng.randi_range(0, options.size() - 1)]
		else:
			result += character
	
	return result


func generate_ip_address() -> String:
	var result: String
	for i in 4:
		result += str(randi_range(0, 255))
		
		if i != 3:
			result += "."
			
	
	return result


func assign_player_data() -> Dictionary:
	var ttl: int = randi_range(7, 12)
	var givenDomainName: String
	var givenIpAddress: String = generate_ip_address()
	var dnsDestination: String = possibleValidDnsNames.pick_random()
	
	var returnData: Dictionary = {
		PlayerData.TIME_TO_RESOLVE : ttl,
		PlayerData.DNS_DESTINATION : dnsDestination,
		PlayerData.IP_ADDRESS : givenIpAddress
	}
	print(returnData)
	
	
	return returnData
